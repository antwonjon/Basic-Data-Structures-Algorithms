package inlab1;

/**
 *
 * @author yaw
 */
public class LinkedList {

    private Node head;
    private int size;
    private Node currentNode;
    private Node previousNode;
    private Node nextNode;

    public LinkedList() {

    }

    public void addInOrder(int value) {
        Node newNode;
        if (head == null) {
            head = new Node(value, null);
        } else if (head.getElement() < value) {
            head = new Node(value, head);
        } else {
            currentNode = head.getNextNode();
            previousNode = head;
            do {

                if (value >= nextNode.getElement()) {
                    newNode = new Node(value, null);
                    nextNode.setNextNode(newNode);
                    previousNode = previousNode.getNextNode();
                    currentNode = currentNode.getNextNode();

                    break;
                } else if (nextNode == null) {
                    previousNode = currentNode.getNextNode();
                    nextNode = nextNode.getNextNode();
                    currentNode = new Node(value, currentNode);
                }
            } while (currentNode != null);

        }
        //    public void removeAtIndex(int index) {
        //        //your code goes here
        //    }

    public void printList() {
        if (head != null) {
            Node currentNode = head;
            int i = 1;
            do {
                System.out.println(i + ") " + currentNode.getElement());
                i++;
                currentNode = currentNode.getNextNode();
            } while (currentNode != null);
        }
        System.out.println();
    }
}
