/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package outlab5;

/**
 *
 * @author AJ
 */
public class OutLab5 {
    
    public static void main(String[] args) {
        Integer[] array = {15, 7, 24, 6, 9, 0, 111, 33, 4};
        BinaryTree.printArray(array);
        BinaryTree.insertArray(array);
        BinaryTree.printArray(array);
       
    }

}
